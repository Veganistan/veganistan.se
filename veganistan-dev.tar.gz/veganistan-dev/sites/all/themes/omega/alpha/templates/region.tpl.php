<?php 
/**
 * @file
 * Alpha's theme implementation to display a region.
 */
?>
<div<?php print $attributes; ?>>
  <div<?php print $content_attributes; ?>>
    <?php print $content; ?>
  </div>
</div>